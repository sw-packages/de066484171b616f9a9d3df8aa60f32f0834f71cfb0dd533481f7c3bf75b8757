# Benchmark

This directory contains the scripts to execute benchmarks of the parser. We use [Google Benchmark](https://github.com/google/benchmark) to define and run benchmarks.

## Install Google Benchmark

```bash
cmake -DCMAKE_BUILD_TYPE=Release

make

make install
```

